<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

include('config.php');

$is_admin = false;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $query = "SELECT is_admin FROM users WHERE id = '$user_id'";
    $result = mysqli_query($con, $query);
    if ($result && $row = mysqli_fetch_assoc($result)) {
        $is_admin = $row['is_admin'] == 1;
    }
}

$upload_error = '';
$upload_success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_product']) && $is_admin) {
    $name = trim($_POST['name']);
    $price = floatval($_POST['price']);
    $description = trim($_POST['description']);
    
    if (empty($name) || $price <= 0 || empty($_FILES['image']['name'])) {
        $upload_error = "All fields are required, and price must be positive.";
    } else {
        $image_type = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (!in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
            $upload_error = "Only JPG, JPEG, PNG, or GIF files are allowed.";
        } elseif ($_FILES['image']['size'] > 5000000) {
            $upload_error = "Image size must be less than 5MB.";
        } else {
            $image_data = file_get_contents($_FILES['image']['tmp_name']);
            if ($image_data === false) {
                $upload_error = "Failed to read image data.";
            } else {
                // Escape strings to prevent SQL issues (minimal for sample)
                $name = mysqli_real_escape_string($con, $name);
                $description = mysqli_real_escape_string($con, $description);
                // Use base64 for image data to avoid binary issues
                $image_data = base64_encode($image_data);
                $query = "INSERT INTO products (name, price, image, description) VALUES ('$name', '$price', '$image_data', '$description')";
                if (mysqli_query($con, $query)) {
                    $upload_success = "Product uploaded successfully!";
                } else {
                    $upload_error = "Failed to upload product: " . mysqli_error($con);
                }
            }
        }
    }
}

$query = "SELECT id, name, price, image, description FROM products ORDER BY id ASC";
$result = mysqli_query($con, $query);

if ($result) {
    $products = mysqli_fetch_all($result, MYSQLI_ASSOC);
    foreach ($products as &$product) {
        if (!empty($product['image'])) {
            // Decode base64 image if stored as base64
            $mime_type = 'image/' . (pathinfo($product['name'], PATHINFO_EXTENSION) ?: 'jpeg');
            $product['image_base64'] = 'data:' . $mime_type . ';base64,' . $product['image'];
        } else {
            $product['image_base64'] = '';
        }
    }
} else {
    echo "Query Error: " . mysqli_error($con);
    $products = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BUYBD - Your Shopping Partner</title>
    <link rel="stylesheet" href="buybd.css">
</head>
<body>
    <div id="container">
        <div id="navbar">
            <div id="logo">
                <img src="images/brandlogo.png" alt="Brand Logo">
            </div>
            <nav>
                <a href="buybd.php"><button>Home</button></a>
                <a href="product.php"><button>See Products</button></a>
                <a href="about.php"><button>About</button></a>
                <a href="contact.php"><button>Contact</button></a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="logout.php"><button>Logout</button></a>
                <?php else: ?>
                    <a href="login.php"><button>Log in/Signup</button></a>
                <?php endif; ?>
            </nav>
        </div>

        <div id="banner">
            <div>
                <h1>Unbeatable Prices for<br>Top-Quality Products!</h1>
                <a href="explore.php"><button>Explore More</button></a>
            </div>
            <div class="image-container">
                <img src="images/bnmodel.png" alt="Banner Image">
            </div>
        </div>

        <?php if ($is_admin): ?>
            <section id="upload-form">
                <h3>Add New Product (Admin Only)</h3>
                <?php if ($upload_error): ?>
                    <p class="error"><?php echo $upload_error; ?></p>
                <?php endif; ?>
                <?php if ($upload_success): ?>
                    <p class="success"><?php echo $upload_success; ?></p>
                <?php endif; ?>
                <form method="post" enctype="multipart/form-data">
                    <label for="name">Product Name</label>
                    <input type="text" id="name" name="name" required>
                    
                    <label for="price">Price (BDT)</label>
                    <input type="number" id="price" name="price" step="0.01" min="0" required>
                    
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="5"></textarea>
                    
                    <label for="image">Product Image</label>
                    <input type="file" id="image" name="image" accept="image/*" required>
                    
                    <button type="submit" name="upload_product">Upload Product</button>
                </form>
            </section>
        <?php endif; ?>

        <section>
            <h2>Our Products</h2>
            <?php if (empty($products)): ?>
                <p>No products available.</p>
            <?php else: ?>
                <div class="product-grid">
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <?php if (!empty($product['image_base64'])): ?>
                                <img src="<?php echo htmlspecialchars($product['image_base64']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <?php else: ?>
                                <img src="images/placeholder.png" alt="No image">
                            <?php endif; ?>
                            <h4><?php echo htmlspecialchars($product['name']); ?></h4>
                            <p><?php echo htmlspecialchars($product['price']); ?>/-</p>
                            <a href="product.php?id=<?php echo $product['id']; ?>"><button>View Details</button></a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section id="testimonials">
            <h2>Why Choose Us</h2>
            <div class="testimonial-grid">
                <div class="testimonial-card">
                    <img src="images/user-1.jpg" alt="User">
                    <p>Best site to buy. Genuine products and great experience. Highly recommend!</p>
                    <h3>Rifat Noor</h3>
                </div>
                <div class="testimonial-card">
                    <img src="images/user-2.jpg" alt="User">
                    <p>Exceeded expectations with fast delivery and competitive prices.</p>
                    <h3>Soumya Mallik</h3>
                </div>
                <div class="testimonial-card">
                    <img src="images/user-3.jpg" alt="User">
                    <p>First purchase was a success. Timely delivery and great service!</p>
                    <h3>Ashikur Rahman</h3>
                </div>
            </div>
        </section>

        <section id="payment-partners">
            <h2>Discounts with Our Payment Partners</h2>
            <div class="partner-grid">
                <div class="partner-card">
                    <img src="images/bksh.png" alt="Bkash">
                </div>
                <div class="partner-card">
                    <img src="images/ngd.png" alt="Nagad">
                </div>
                <div class="partner-card">
                    <img src="images/rkt.png" alt="Rocket">
                </div>
                <div class="partner-card">
                    <img src="images/visa.png" alt="Visa">
                </div>
                <div class="partner-card">
                    <img src="images/mstr.png" alt="Mastercard">
                </div>
            </div>
        </section>

        <section id="footer-links">
            <h2>Learn More</h2>
            <div class="footer-grid">
                <div class="footer-card">
                    <img src="images/brandlogo.png" alt="Brand Logo">
                    <p>Your Trusted Shopping Platform</p>
                </div>
                <div class="footer-card">
                    <h3>Download Our App</h3>
                    <ul>
                        <li>Android</li>
                        <li>iOS</li>
                    </ul>
                </div>
                <div class="footer-card">
                    <h3>Join for More</h3>
                    <ul>
                        <li>Coupons</li>
                        <li>Blog Post</li>
                        <li>Return Policy</li>
                        <li>Join Affiliates</li>
                    </ul>
                </div>
                <div class="footer-card">
                    <h3>Follow Us</h3>
                    <ul>
                        <li>Facebook</li>
                        <li>Twitter</li>
                        <li>Instagram</li>
                        <li>Join Affiliates</li>
                    </ul>
                </div>
            </div>
        </section>

        <div id="footer">
            <p>BUYBD International Ltd.</p>
        </div>
    </div>
</body>
</html>