<?php
session_start();

include('config.php');

$error = '';
$success = '';
$product = null;

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = intval($_GET['id']);
    $query = "SELECT id, name, price FROM products WHERE id = '$product_id'";
    $result = mysqli_query($con, $query);
    
    if ($result && $row = mysqli_fetch_assoc($result)) {
        $product = $row;
    } else {
        $error = "Product not found.";
    }
} else {
    $error = "Invalid product ID.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order']) && $product) {
    $name = trim($_POST['name']);
    $mobile_number = trim($_POST['mobile_number']);
    $address = trim($_POST['address']);
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    
    if ($quantity < 1) {
        $quantity = 1;
    }

    if (empty($name) || empty($mobile_number) || empty($address)) {
        $error = "All fields are required.";
    } elseif (!preg_match("/^[0-9]{10,15}$/", $mobile_number)) {
        $error = "Please enter a valid mobile number.";
    } else {
        $user_id = $_SESSION['user_id'];
        $name = mysqli_real_escape_string($con, $name);
        $mobile_number = mysqli_real_escape_string($con, $mobile_number);
        $address = mysqli_real_escape_string($con, $address);
        $query = "INSERT INTO orders (user_id, product_id, quantity, name, mobile_number, address) VALUES ('$user_id', '$product_id', '$quantity', '$name', '$mobile_number', '$address')";
        
        if (mysqli_query($con, $query)) {
            $success = "Order placed successfully!";
        } else {
            $error = "Failed to place order. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place Order - BUYBD</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
       }

        #container {
            max-width: 1280px;
            margin: 0 auto;
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #navbar {
            background-color: #2c3e50;
            display: flex;
            align-items: center;
            padding: 15px 20px;
        }

        #logo img {
            max-height: 50px;
        }

        nav {
            flex: 1;
            text-align: right;
        }

        nav a {
            margin: 0 15px;
            text-decoration: none;
        }

        nav button {
            padding: 10px 20px;
            border: none;
            background-color: #27ae60;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            font-size: 0.9em;
            transition: background-color 0.3s;
        }

        nav button:hover {
            background-color: #219653;
        }

        .order-form {
            padding: 40px 20px;
            max-width: 600px;
            margin: 0 auto;
        }

        .order-form h1 {
            font-size: 2em;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
        }

        .order-form .product-info {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }

        .order-form .product-info p {
            margin-bottom: 10px;
            color: #2c3e50;
        }

        .order-form form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .order-form label {
            font-size: 1.1em;
            color: #2c3e50;
        }

        .order-form input,
        .order-form textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
            width: 100%;
        }

        .order-form input[type="number"] {
            width: 100px;
        }

        .order-form button {
            padding: 12px 25px;
            background-color: #27ae60;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
            align-self: center;
        }

        .order-form button:hover {
            background-color: #219653;
        }

        .error {
            color: #c0392b;
            margin-bottom: 15px;
            text-align: center;
        }

        .success {
            color: #27ae60;
            margin-bottom: 15px;
            text-align: center;
        }

        #footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 20px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .order-form {
                padding: 20px;
            }
        }

        @media (max-width: 480px) {
            .order-form h1 {
                font-size: 1.5em;
            }

            .order-form button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div id="container">
        <div id="navbar">
            <div id="logo">
                <img src="images/brandlogo.png" alt="Brand Logo">
            </div>
            <nav>
                <a href="buybd.php"><button>Home</button></a>
                <a href="products.php"><button>See Products</button></a>
                <a href="about.php"><button>About</button></a>
                <a href="contact.php"><button>Contact</button></a>
                <a href="logout.php"><button>Logout</button></a>
            </nav>
        </div>

        <div class="order-form">
            <h1>Place Your Order</h1>
            <?php if ($error): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php elseif ($success): ?>
                <div class="success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            <?php if ($product): ?>
                <div class="product-info">
                    <p><strong>Product:</strong> <?php echo htmlspecialchars($product['name']); ?></p>
                    <p><strong>Price:</strong> <?php echo htmlspecialchars($product['price']); ?> BDT</p>
                </div>
                <form method="post">
                    <label for="name">Full Name:</label>
                    <input type="text" name="name" id="name" required>
                    
                    <label for="mobile_number">Mobile Number:</label>
                    <input type="text" name="mobile_number" id="mobile_number" required>
                    
                    <label for="address">Delivery Address:</label>
                    <textarea name="address" id="address" rows="4" required></textarea>
                    
                    <label for="quantity">Quantity:</label>
                    <input type="number" name="quantity" id="quantity" value="1" min="1">
                    
                    <button type="submit" name="place_order">Place Order</button>
                </form>
            <?php endif; ?>
        </div>

        <div id="footer">
            <p>BUYBD International Ltd.</p>
        </div>
    </div>
</body>
</html>