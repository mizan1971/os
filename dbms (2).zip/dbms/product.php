<?php
session_start();

include('config.php');

$error = '';

$product = null;
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = intval($_GET['id']);
    $query = "SELECT id, name, price, image, description FROM products WHERE id = '$product_id'";
    $result = mysqli_query($con, $query);
    
    if ($result && $row = mysqli_fetch_assoc($result)) {
        $product = $row;
        if (!empty($product['image'])) {
            // Image is already base64-encoded in the database
            $mime_type = 'image/' . (pathinfo($product['name'], PATHINFO_EXTENSION) ?: 'jpeg');
            $product['image_base64'] = 'data:' . $mime_type . ';base64,' . $product['image'];
        } else {
            $product['image_base64'] = 'images/placeholder.png'; 
        }
    } else {
        $error = "Product not found.";
    }
} else {
    $error = "Invalid product ID.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product ? htmlspecialchars($product['name']) : 'Product Details'; ?> - BUYBD</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
        }

        #container {
            max-width: 1280px;
            margin: 0 auto;
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #navbar {
            background-color:rgb(60, 156, 252);
            display: flex;
            align-items: center;
            padding: 15px 20px;
        }

        #logo img {
            max-height: 50px;
        }

        nav {
            flex: 1;
            text-align: right;
        }

        nav a {
            margin: 0 15px;
            text-decoration: none;
        }

        nav button {
            padding: 10px 20px;
            border: none;
            background-color: #27ae60;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            font-size: 0.9em;
            transition: background-color 0.3s;
        }

        nav button:hover {
            background-color: #219653;
        }

        .product-details {
            padding: 40px 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            align-items: flex-start;
        }

        .product-image {
            flex: 1;
            min-width: 300px;
            text-align: center;
        }

        .product-image img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .product-info {
            flex: 1;
            min-width: 300px;
        }

        .product-info h1 {
            font-size: 2em;
            color: #2c3e50;
            margin-bottom: 15px;
        }

        .product-info p.price {
            font-size: 1.5em;
            color:rgb(30, 128, 79);
            margin-bottom: 20px;
        }

        .product-info p.description {
            color: #7f8c8d;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .product-info form {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
        }

        .product-info input[type="number"] {
            width: 60px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
        }

        .product-info button {
            padding: 12px 25px;
            background-color: #27ae60;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }

        .product-info button:hover {
            background-color: #219653;
        }

        .error {
            color: #c0392b;
            margin-bottom: 15px;
            text-align: center;
        }

        .success {
            color: #27ae60;
            margin-bottom: 15px;
            text-align: center;
        }

        #footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 20px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .product-details {
                flex-direction: column;
                align-items: center;
            }

            .product-image, .product-info {
                min-width: 100%;
            }
        }

        @media (max-width: 480px) {
            .product-info h1 {
                font-size: 1.5em;
            }

            .product-info p.price {
                font-size: 1.2em;
            }

            .product-info form {
                flex-direction: column;
                align-items: flex-start;
            }

            .product-info input[type="number"] {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div id="container">
        <div id="navbar">
            <div id="logo">
                <img src="images/brandlogo.png" alt="Brand Logo">
            </div>
            <nav>
                <a href="buybd.php"><button>Home</button></a>
                <a href="products.php"><button>See Products</button></a>
                <a href="about.php"><button>About</button></a>
                <a href="contact.php"><button>Contact</button></a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="logout.php"><button>Logout</button></a>
                <?php else: ?>
                    <a href="login.php"><button>Log in/Signup</button></a>
                <?php endif; ?>
            </nav>
        </div>
        <div class="product-details">
            <?php if ($error): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php elseif ($product): ?>
                <div class="product-image">
                    <img src="<?php echo htmlspecialchars($product['image_base64']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                </div>
                <div class="product-info">
                    <h1><?php echo htmlspecialchars($product['name']); ?></h1>
                    <p class="price"><?php echo htmlspecialchars($product['price']); ?> BDT</p>
                    <p class="description"><?php echo htmlspecialchars($product['description'] ?: 'No description available.'); ?></p>
                    <a href="buynow.php?id=<?php echo $product['id']; ?>"><button type="button" name="buy_now">Buy Now</button></a>
                </div>
            <?php endif; ?>
        </div>
        <div id="footer">
            <p>BUYBD International Ltd.</p>
        </div>
    </div>
</body>
</html>