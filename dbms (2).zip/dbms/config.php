<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'buybd';

$con = mysqli_connect($host, $user, $password, $dbname);


if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_set_charset($con, 'utf8');
?>